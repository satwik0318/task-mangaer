const notfound=(req,res)=>{
    res.status(404).send('error not found ')
}
module.exports=notfound