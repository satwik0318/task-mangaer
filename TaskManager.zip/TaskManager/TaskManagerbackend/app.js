require('dotenv').config()
const connectDB= require('./db/connect')
const express=require('express')
const app=express()
const tasks=require('./routes/tasks')
const task =require("./models/Task")
const notFound=require('./middleware/notfound')
const errorhandler=require('./middleware/errorhandle')
app.use(express.static('./frontend'))
app.use(express.json())
app.use('/api/v1/tasks',tasks)
app.use(notFound)
app.use(errorhandler)
const port=process.env.PORT||5000
const start=async()=>{
    try {
        await connectDB(process.env.MONGO_URI)
        app.listen(port, console.log(`server is listening ${port} ...`))
    } catch (error) {
        console.log(error)
    }
}
start()
